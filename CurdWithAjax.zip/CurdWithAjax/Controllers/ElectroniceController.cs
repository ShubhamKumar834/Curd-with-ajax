﻿using CurdWithAjax.DataAccess;
using CurdWithAjax.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CurdWithAjax.Controllers
{
    public class ElectroniceController : Controller
    {
        private readonly EStoreDataContext eStoreData;
        public ElectroniceController(EStoreDataContext storeDataContext)
        {
            eStoreData = storeDataContext;
        }

        [HttpGet]
        public IActionResult EIndex()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetAllProducts()
        {
            var StoreData = eStoreData.products.ToList();
            return new JsonResult(StoreData);
        }

        [HttpPost]
        public JsonResult Addemp(Products products)
        {
            var data = new Products()
            {
                Product=products.Product,
                Quantity=products.Quantity,
                ProductCode=products.ProductCode
            };
            eStoreData.products.Add(data);
            eStoreData.SaveChanges();
            return new JsonResult("Data is saved..");        
        }

        [HttpGet]
        public JsonResult Edit(int id)
        {
            var Iid = eStoreData.products.Where(Iid => Iid.Id == id).SingleOrDefault();
            return new JsonResult(Iid);
        }

        [HttpPost]
        public JsonResult UpdateItem(Products products)
        {
            eStoreData.products.Update(products);
            eStoreData.SaveChanges();
            return new JsonResult("Data Updated..");
        }

        [HttpGet]
        public JsonResult DeleteItem(int id)
        {
            var itemid = eStoreData.products.Where(itid => itid.Id == id).SingleOrDefault();
            eStoreData.products.Remove(itemid);
            eStoreData.SaveChanges();
            return new JsonResult("Data Deleted..");
        }
    }
}
