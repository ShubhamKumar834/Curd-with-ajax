﻿
$(document).ready(function () {
    getdata();
});

//Get All data function......
function getdata() {
    $.ajax({
        url: '/Electronice/GetAllProducts',
        type: 'Get',
        dataType: 'json',
        contentType: 'application/json;charset=utf-8;',
        success: function (result,status,xhr) {
            var object = '';
            $.each(result, function (index, data) {
                object += '<tr>';
                object += '<td>' + data.id + '</td>';
                object += '<td>' + data.product + '</td>';
                object += '<td>' + data.quantity + '</td>';
                object += '<td>' + data.productCode + '</td>';
                object += '<td><a href="#" onclick="Editdata(' + data.id + ');" class="btn btn-info">Edit</a> || <a href="#" onclick="deletedata(' + data.id + ');" class="btn btn-danger">Delete</a></td>';
                object += '</tr>';
            });
            $('#tabledata').html(object);
        },
        error: function () {
            alert("Data can not be access!");
        }
    });
};

//Modalpopup for add data...
$('#btnadd').click(function () {
    $('#itemmodal').modal('show');
    $('#update').hide();
    $('#mhead').text('Add New Item');
    $('#add').show();
})

//Add item function.......
function additem() {
    var objdata =
    {
        Product: $('#Product').val(),
        Quantity: $('#Quantity').val(),
        ProductCode: $('#ProductCode').val()
    }
    $.ajax({
        url: '/Electronice/Addemp',
        type: 'Post',
        data: objdata,
        contentType: 'application/x-www-form-urlencoded;charset=utf-8;',
        dataType: 'Json',
        success: function () {
            alert("Data saved successfully.");
            cleartextbox();
            hidemodal();
            getdata();
        },
        error: function () {
            alert("Data can not saved..");
        }
    });
};

//Hide modal after create data...
function hidemodal() {
    $('#itemmodal').modal('hide');
}

//Clear modal after save/update data...
function cleartextbox() {
    $('#Pid').val('');
    $('#Product').val('');
    $('#Quantity').val('');
    $('#ProductCode').val('');
}

//Delete function for data..
function deletedata(id) {
    if (confirm("Are you sure you want to delete this record parmanant!!")) {
        $.ajax({
            url: '/Electronice/DeleteItem?id=' + id,
            success: function () {
                alert("Data Deleted Successfully..");
                getdata();
            },
            error: function () {
                alert("Data Can't be delete..");
            }
        });
    }
}

//function for Editdata..
function Editdata(id) {
    $.ajax({
        url: '/Electronice/Edit?id=' + id,
        type: 'Get',
        contentType: 'application/json;charset=utf-8;',
        dataType:'json',
        success: function (response) {
            $('#itemmodal').modal('show');
            $('#mhead').text('Update Record.');
            $('#Pid').val(response.id);
            $('#Product').val(response.product);
            $('#Quantity').val(response.quantity);
            $('#ProductCode').val(response.productCode);
            $('#add').hide();
            $('#update').show();
        },
        error: function () {
            alert("Data can not found..");
        }
    });
}

//function for update data...
function updatedata() {
    var objdata =
        {
            Id: $('#Pid').val(),
            Product: $('#Product').val(),
            Quantity: $('#Quantity').val(),
            ProductCode: $('#ProductCode').val()
        }
    if (confirm("Are you sure you want to update this record?.")) {
        $.ajax({
            url: '/Electronice/UpdateItem',
            type: 'Post',
            data: objdata,
            contentType: 'application/x-www-form-urlencoded;charset=utf-8;',
            dataType: 'Json',
            success: function () {
                alert("Data updated successfully.");
                cleartextbox();
                hidemodal();
                getdata();
            },
            error: function () {
                alert("Data can not update..");
            }
        });
    }
}

