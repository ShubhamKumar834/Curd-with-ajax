﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CurdWithAjax.Models
{
    public class Products
    {
        public int Id { get; set; } 
        public string Product { get; set; }
        public int Quantity { get; set; }
        public int ProductCode { get; set; }
    }
}
