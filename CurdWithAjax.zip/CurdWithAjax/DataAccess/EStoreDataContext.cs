﻿using CurdWithAjax.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CurdWithAjax.DataAccess
{
    public class EStoreDataContext:DbContext
    {
        public EStoreDataContext(DbContextOptions<EStoreDataContext> options):base(options)
        {

        }
    public DbSet<Products> products { get; set; } 
    }
}
